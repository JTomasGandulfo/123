

function resolverAcceso() {
    $.get('https://www.inacap.cl/ip.php', function (ip) {
        //var ip = '172.16.98.17';
        var matchAdministrativo = '172.16';
        var matchAcademico = '10.';
        var esAdministrativo = ip.indexOf(matchAdministrativo) > -1;
        var esAcademico = ip.indexOf(matchAcademico) > -1;

        console.log(ip);
        // console.log(esAcademico);

        if (esAdministrativo || esAcademico) {
            console.log('Valido!');            
        } else {
        	console.log('No Valido!');
            // PREGRADO
            $('.linksIntranet li:eq(0) a').attr('href', 'javascript:void(0)').removeAttr('target');
            $('.accesos-directos a:eq(0)').attr('href','javascript:void(0)').removeAttr('target');

        }


    });
}

if ('jQuery' in window) {
    $(document).ready(function () {
       // nresolverAcceso();
    });    
}