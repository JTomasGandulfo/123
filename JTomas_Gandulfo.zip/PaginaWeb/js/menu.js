(function($) {
	$(window).bind("load", function() {
		if(window.innerWidth < 990 ) {

			/* Toggle Button */
			var toggleButton = document.getElementsByClassName('toggleMenu')[0];
			toggleButton.onclick = function(){
				var submenuContainer = findAncestor(toggleButton, 'submenu-container' );
				
				if(hasClass(submenuContainer, 'active')) {
					submenuContainer.classList.remove('active')
				} else {
					submenuContainer.classList.add('active')
				}
			}

			function findAncestor (el, cls) {
			    while ((el = el.parentElement) && !el.classList.contains(cls));
			    return el;
			}
			function hasClass( target, className ) {
			    return new RegExp('(\\s|^)' + className + '(\\s|$)').test(target.className);
			}

			  
			/* Submenu Height */
			var height;
			var menuHeight;
			var submenuContent;

			submenuContent = document.getElementById('submenu-content');
			menuHeight = document.getElementsByClassName('menu')[0].style.height;
			console.log(menuHeight);
			height = window.innerHeight - 50;
			submenuContent.style.height = height + 'px';
		}
	});
})(jQuery);