$(document).ready(function(){
	var urlcarga = "https://widgets.inacap.cl/wdbuscadorcarreras/selectbuscadorcarreras.php"; // En Test y producciÃ³n se debe editar y ajustar
	$.get(urlcarga, function(respuesta){
			$("#widgetbuscador").html(respuesta);
	});    

})