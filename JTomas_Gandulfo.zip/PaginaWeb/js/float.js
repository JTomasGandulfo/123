$(window).on('resize', actualizarAncho);

var flotante = $('.flotante')
var contenido = $('.contenido-flotante')
var ocultar = $('#btn-ocultar-flotante')
var mostrar = $('#btn-mostrar-flotante')

$(document).ready(function(){

    actualizarAncho();

   
    
    ocultar.click(function(){
        contenido.css('display', 'none');
        flotante.css('width', '150')
        mostrar.removeClass('oculto');
        ocultar.addClass('oculto');
    });
    
    mostrar.click(function(){
        contenido.css('display','block');
        flotante.css('width', '230')
        mostrar.addClass('oculto');
        ocultar.removeClass('oculto');
    });
    
});


function actualizarAncho(){
    //Modificar el titulo de la aplicacion dependiendo del ancho.
    var width = $(window).width();
    if ($(window).width() < 768) {
        contenido.css('display', 'none');
        flotante.css('width', '150')
        mostrar.removeClass('oculto');
        ocultar.addClass('oculto');
    }
};